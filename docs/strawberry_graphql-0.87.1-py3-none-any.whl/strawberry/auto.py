import sentinel


auto = sentinel.create("auto")
