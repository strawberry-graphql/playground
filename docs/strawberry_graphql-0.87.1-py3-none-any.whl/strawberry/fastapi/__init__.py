from strawberry.fastapi.router import GraphQLRouter


__all__ = ["GraphQLRouter"]
